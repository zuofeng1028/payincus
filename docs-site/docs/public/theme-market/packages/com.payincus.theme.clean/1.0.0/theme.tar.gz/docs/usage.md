# Clean Theme Usage

Use this theme as the acceptance sample for the PayIncus theme system.

Validation expectations:

- CSS must be local and must not use remote imports.
- Template fragments must be plain HTML fragments without scripts, forms, iframes, inline event handlers, `javascript:`, or remote URLs.
- The `public.market.banner` fragment is visual-only and must not replace package filtering, pricing, checkout, or provisioning logic.
- The `user.wallet.banner` fragment is visual-only and must not replace recharge providers, payment state, balance mutations, refunds, or accounting records.
- The `user.tickets.banner` fragment is visual-only and must not replace ticket ownership, status transitions, internal notes, AI handoff, attachments, or permissions.
- The `user.extensions.banner` fragment is visual-only and must not replace extension submissions, package scanning, event health, or alert preferences.
- The `user.orders.banner` fragment is visual-only and must not replace order state, payment callbacks, billing records, refunds, or reconciliation.
- The `user.profile.banner` fragment is visual-only and must not replace identity, password, 2FA, OAuth, Telegram, SSH key, notification, or login-history logic.
- The `user.invites.banner` fragment is visual-only and must not replace invite costs, point deductions, redemption rules, or invite usage tracking.
- The `user.hosts.banner` fragment is visual-only and must not replace host status, resource accounting, calibration, hosted-node ownership, or permissions.
- The `user.host.create.banner` fragment is visual-only and must not replace host address validation, port validation, network-mode validation, installation commands, or verification.
- The `admin.extensions.header`, `admin.extensions.market.banner`, and `admin.extensions.theme.banner` fragments are visual-only and must not replace extension review, market installation, theme installation, package validation, or task auditing.
- The `admin.dashboard.widgets` fragment is visual-only and must not replace statistics, risk checks, plugin widgets, or admin actions.
- The `admin.billing.banner`, `admin.payment.providers.banner`, and `admin.oauth.banner` fragments are visual-only and must not replace balances, payment provider secrets, refunds, OAuth client secrets, consent, token rotation, revocation, scopes, or audit records.
- `file` config values must be uploaded through the admin theme configuration form.
- Enabling the theme should expose CSS and template URLs through `GET /api/themes/active`.
- Rolling back should remove the active theme and restore the default visual layer.
